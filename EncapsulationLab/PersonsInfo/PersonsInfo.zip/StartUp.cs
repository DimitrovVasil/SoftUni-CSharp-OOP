﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace PersonsInfo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int count = int.Parse(Console.ReadLine());

            List<Person> people = new List<Person>();

            for (int i = 0; i < count; i++)
            {
                string[] input = Console.ReadLine().Split();

                string firstName = input[0];
                string lastName = input[1];
                int age = int.Parse(input[2]);
                decimal salary = decimal.Parse(input[3]);

                Person person = new Person(firstName, lastName, age, salary);
                people.Add(person);
            }

            decimal percentage = decimal.Parse(Console.ReadLine());

            foreach (var person in people)
            {
                decimal result = person.IncreaseSalary(percentage);
                Console.WriteLine(result.ToString("0.00"));
            }


        }
    }
}
