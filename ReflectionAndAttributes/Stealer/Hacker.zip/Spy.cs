﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Linq;

namespace Stealer
{
    public class Spy
    {
        public string StealFieldInfo(string className, params string[] strings)
        {
            Type investigatedClass = Type.GetType(className);
            var instance = Activator.CreateInstance(investigatedClass);
            FieldInfo[] fields = investigatedClass.GetFields(BindingFlags.NonPublic | BindingFlags.Instance |BindingFlags.Static | BindingFlags.Public);           

            StringBuilder sb = new StringBuilder($"Class under investigation: {instance.GetType()}" + Environment.NewLine);
            
            foreach (var field in fields)
            {
                if (strings.Contains(field.Name))
                {
                    sb.AppendLine($"{field.Name} = {field.GetValue(instance)}");
                }
                
            }

            return sb.ToString().TrimEnd();

        }
    }
}




















//Type classNeeded = Type.GetType(className);

//FieldInfo[] fields = classNeeded.GetFields(BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public);
//StringBuilder sb = new StringBuilder();

//Object instance = Activator.CreateInstance(classNeeded, new object[] { });
//var fieldsNeeded = fields.Where(f => strings.Contains(f.Name)).ToList();

//sb.AppendLine($"Class under investigation: {className}");

//foreach (var field in fieldsNeeded)
//{
//    sb.AppendLine($"{field.Name} = {field.GetValue(instance)}");
//}

//var result = sb.ToString().Trim();

//return result;