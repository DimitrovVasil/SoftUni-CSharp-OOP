﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EasterRaces.Repositories.Entities
{
    public class RaceRepository<T> : Repository<T>
    {
    }
}
