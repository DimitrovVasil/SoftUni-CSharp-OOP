﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EasterRaces.Repositories.Entities
{
    public class DriverRepository<T> : Repository<T>
    {
    }
}
