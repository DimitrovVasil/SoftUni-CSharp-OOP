﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EasterRaces.Repositories.Entities
{
    public class CarRepository<T> : Repository<T>
    {
        public CarRepository()
        {
            Models = new List<T>();
        }
    }
}
